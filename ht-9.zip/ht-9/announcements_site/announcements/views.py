from django.shortcuts import render, get_object_or_404,redirect
from .models import Announcement, Category
from .forms import AnnouncementForm

# Create your views here.


def announcement_list(request):
    categories = Category.objects.all()
    announcements = Announcement.objects.all()
    return render(request, 'announcement_list.html', {'categories': categories, 'announcements': announcements})


def announcement_details(request, id):
    announcement = get_object_or_404(Announcement, id=id)
    return render(request, 'announcement_details.html', {'announcement': announcement})



def add_announcement(request):
    categories = Category.objects.all()  
    if request.method == 'POST':
        form = AnnouncementForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('announcement_list')
    else:
        form = AnnouncementForm()
    
    return render(request, 'add_announcement.html', {'form': form, 'categories': categories})

def select_by_category(request, category_id):
    category = get_object_or_404(Category, id=category_id)
    announcements = Announcement.objects.filter(category=category)
    categories = Category.objects.all()  
    return render(request, 'announcement_list.html', {'announcements': announcements, 'categories': categories})
