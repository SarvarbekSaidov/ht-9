from django.urls import path
from . import views

urlpatterns = [
    path('', views.announcement_list, name='announcement_list'),
    path('announcement/<int:id>/', views.announcement_details, name='announcement_details'),
    path('add/', views.add_announcement, name='add_announcement'),
    path('category/<int:category_id>/', views.select_by_category, name='select_by_category'),
]

